Cowboy examples
===============

The Cowboy examples can be found in a separate repository:

* https://github.com/extend/cowboy_examples
